package org.mortbay.cometd.jquery;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import org.mozilla.javascript.ScriptableObject;
import org.testng.annotations.Test;

/**
 * @version $Revision: 1361 $ $Date: 2008-12-16 04:59:27 -0600 (Tue, 16 Dec 2008) $
 */
public class CometBatchPublishTest extends CometTest
{
    @Test
    public void testBatchPublish() throws Exception
    {
        ScriptableObject.defineClass(jsScope, Listener.class);
        StringBuilder script = new StringBuilder();
        script.append("var listener = new Listener();");
        script.append("var _connected;");
        script.append("function connected(message)");
        script.append("{ ");
        script.append("    var wasConnected = _connected;");
        script.append("    _connected = message.successful;");
        script.append("    if (!wasConnected && connected)");
        script.append("    {");
        script.append("        $.comet.startBatch();");
        script.append("        $.comet.subscribe('/echo', listener, listener.handle); ");
        script.append("        $.comet.publish('/echo', 'test'); ");
        script.append("        $.comet.endBatch(); ");
        script.append("    }");
        script.append("}");
        script.append("$.comet.addListener('/meta/connect', this, connected);");
        evaluateScript(script.toString());
        Listener listener = (Listener)jsScope.get("listener", jsScope);

        listener.jsFunction_expect(1);
        evaluateScript("$.comet.init('" + cometURL + "')");
        assert listener.await(1000);

        evaluateScript("var disconnectListener = new Listener();");
        Listener disconnectListener = (Listener)jsScope.get("disconnectListener", jsScope);
        disconnectListener.jsFunction_expect(1);
        evaluateScript("$.comet.addListener('/meta/disconnect', disconnectListener, disconnectListener.handle);");
        evaluateScript("$.comet.disconnect();");
        assert disconnectListener.await(1000);
    }

    public static class Listener extends ScriptableObject
    {
        private CountDownLatch latch;

        public void jsFunction_expect(int messageCount)
        {
            latch = new CountDownLatch(messageCount);
        }

        public String getClassName()
        {
            return "Listener";
        }

        public void jsFunction_handle(Object message)
        {
            if (latch.getCount() == 0) throw new AssertionError();
            latch.countDown();
        }

        public boolean await(long timeout) throws InterruptedException
        {
            return latch.await(timeout, TimeUnit.MILLISECONDS);
        }
    }
}
