package org.mortbay.cometd.jquery;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import org.mozilla.javascript.ScriptableObject;
import org.testng.annotations.Test;

/**
 * @version $Revision: 1361 $ $Date: 2008-12-16 04:59:27 -0600 (Tue, 16 Dec 2008) $
 */
public class CometPublishTest extends CometTest
{
    @Test
    public void testPublish() throws Exception
    {
        ScriptableObject.defineClass(jsScope, Listener.class);
        evaluateScript("$.comet.init('" + cometURL + "')");

        // Wait for the long poll
        Thread.sleep(1000);

        evaluateScript("var echoListener = new Listener();");
        Listener echoListener = (Listener)jsScope.get("echoListener", jsScope);
        evaluateScript("var subscription = $.comet.subscribe('/echo', echoListener, echoListener.handle);");
        evaluateScript("var publishListener = new Listener();");
        Listener publishListener = (Listener)jsScope.get("publishListener", jsScope);
        evaluateScript("$.comet.addListener('/meta/publish', publishListener, publishListener.handle);");

        echoListener.jsFunction_expect(1);
        publishListener.jsFunction_expect(1);
        evaluateScript("$.comet.publish('/echo', 'test');");
        assert echoListener.await(1000);
        assert publishListener.await(1000);

        evaluateScript("var disconnectListener = new Listener();");
        Listener disconnectListener = (Listener)jsScope.get("disconnectListener", jsScope);
        disconnectListener.jsFunction_expect(1);
        evaluateScript("$.comet.addListener('/meta/disconnect', disconnectListener, disconnectListener.handle);");
        evaluateScript("$.comet.disconnect();");
        assert disconnectListener.await(1000);
        String status = (String)evaluateScript("$.comet.getStatus();");
        assert "disconnected".equals(status) : status;
    }

    public static class Listener extends ScriptableObject
    {
        private CountDownLatch latch;

        public void jsFunction_expect(int messageCount)
        {
            latch = new CountDownLatch(messageCount);
        }

        public String getClassName()
        {
            return "Listener";
        }

        public void jsFunction_handle(Object message)
        {
            if (latch.getCount() == 0) throw new AssertionError();
            latch.countDown();
        }

        public boolean await(long timeout) throws InterruptedException
        {
            return latch.await(timeout, TimeUnit.MILLISECONDS);
        }
    }
}
