// ========================================================================
// Copyright 2004-2008 Mort Bay Consulting Pty. Ltd.
// ------------------------------------------------------------------------
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// ========================================================================

package org.mortbay.cometd.jquery;

import java.io.File;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.cometd.demo.BayeuxServicesListener;
import org.mortbay.cometd.continuation.ContinuationCometdServlet;
import org.mortbay.jetty.Server;
import org.mortbay.jetty.handler.HandlerCollection;
import org.mortbay.jetty.nio.SelectChannelConnector;
import org.mortbay.jetty.servlet.Context;
import org.mortbay.jetty.servlet.DefaultServlet;
import org.mortbay.jetty.servlet.ServletHolder;
import org.mortbay.resource.ResourceCollection;
import org.mozilla.javascript.NativeArray;
import org.mozilla.javascript.NativeObject;
import org.mozilla.javascript.ScriptableObject;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

/**
 * @version $Revision: 1387 $ $Date: 2009-01-13 17:18:38 -0600 (Tue, 13 Jan 2009) $
 */
public class CometTest
{
    protected int port;
    protected String contextPath;
    protected String baseURL;
    protected String cometServletPath = "/cometd";
    protected String cometURL;
    protected int longPollingPeriod = 5000;
    protected org.mozilla.javascript.Context jsContext;
    protected ScriptableObject jsScope;
    private Server server;
    private int scripts = 0;

    @BeforeMethod
    public void startComet() throws Exception
    {
        server = new Server();
        SelectChannelConnector connector = new SelectChannelConnector();
        server.addConnector(connector);

        HandlerCollection handlers = new HandlerCollection();
        server.setHandler(handlers);

        contextPath = "/cometd";
        Context context = new Context(handlers, contextPath, Context.SESSIONS);

        File baseDirectory = new File(System.getProperty("basedir","."));
        context.setBaseResource(new ResourceCollection(new String[]
        {
            new File(baseDirectory, "src/main/webapp").getCanonicalPath(),
            new File(baseDirectory, "src/test/resources").getCanonicalPath()
        }));

        // Setup default servlet
        context.addServlet(DefaultServlet.class, "/");

        // Setup comet servlet
        ContinuationCometdServlet cometServlet = new ContinuationCometdServlet();
        ServletHolder cometServletHolder = new ServletHolder(cometServlet);
        cometServletHolder.setInitParameter("timeout", String.valueOf(longPollingPeriod));
        cometServletHolder.setInitParameter("loglevel","2");
        context.addServlet(cometServletHolder, cometServletPath +"/*");

        // Setup bayeux listener
        context.addEventListener(new BayeuxServicesListener());

        customizeContext(context);

        server.start();
        port = connector.getLocalPort();

        baseURL = "http://localhost:" + port + contextPath;
        cometURL = baseURL + cometServletPath;

        jsContext = org.mozilla.javascript.Context.enter();
        jsScope = jsContext.initStandardObjects();
        URL envURL = new URL(baseURL + "/env.js");
        jsContext.evaluateReader(jsScope, new InputStreamReader(envURL.openStream()), envURL.toExternalForm(), 1, null);
        evaluateScript("window.location = '" + baseURL + "'");
        URL json2URL = new URL(baseURL + "/jquery/json2.js");
        jsContext.evaluateReader(jsScope, new InputStreamReader(json2URL.openStream()), json2URL.toExternalForm(), 1, null);
        URL jqueryURL = new URL(baseURL + "/jquery/jquery.js");
        jsContext.evaluateReader(jsScope, new InputStreamReader(jqueryURL.openStream()), jqueryURL.toExternalForm(), 1, null);
        URL jqueryCometURL = new URL(baseURL + "/jquery/jquery.comet.js");
        jsContext.evaluateReader(jsScope, new InputStreamReader(jqueryCometURL.openStream()), jqueryCometURL.toExternalForm(), 1, null);
    }

    @AfterMethod(alwaysRun = true)
    public void stopComet() throws Exception
    {
        org.mozilla.javascript.Context.exit();
        server.stop();
        server.join();
        System.out.println("Jetty " + server + " stopped successfully");
    }

    protected void customizeContext(Context context)
    {
    }

    protected Object evaluateScript(String script)
    {
        return jsContext.evaluateString(jsScope, script, nextScriptName(), 1, null);
    }

    protected String nextScriptName()
    {
        return "script_" + ++scripts;
    }

    public static Object jsToJava(Object jsObject)
    {
        if (jsObject == null) return null;
        if (jsObject == org.mozilla.javascript.Context.getUndefinedValue()) return null;
        if (jsObject instanceof String) return jsObject;
        if (jsObject instanceof Boolean) return jsObject;
        if (jsObject instanceof Double) return jsObject;
        if (jsObject instanceof NativeArray) return convertArray((NativeArray)jsObject);
        if (jsObject instanceof NativeObject) return convertObject((NativeObject)jsObject);
        throw new AssertionError("Unknown JS object type");
    }

    private static Object[] convertArray(NativeArray jsArray)
    {
        Object[] ids = jsArray.getIds();
        Object[] result = new Object[ids.length];
        for (int i = 0; i < ids.length; i++)
        {
            Object id = ids[i];
            int index = (Integer)id;
            Object jsValue = jsArray.get(index, jsArray);
            result[i] = jsToJava(jsValue);
        }
        return result;
    }

    private static Object convertObject(NativeObject jsObject)
    {
        Object[] ids = jsObject.getIds();
        Map result = new HashMap(ids.length);
        for (Object id : ids)
        {
            if (id instanceof String)
            {
                Object jsValue = jsObject.get((String)id, jsObject);
                result.put(id, jsToJava(jsValue));
            }
            else if (id instanceof Integer)
            {
                Object jsValue = jsObject.get((Integer)id, jsObject);
                result.put(id, jsToJava(jsValue));
            }
            else
                throw new AssertionError();
        }
        return result;
    }
}
