package org.mortbay.cometd;

import java.io.IOException;
import java.io.UnsupportedEncodingException;

import org.mortbay.io.Buffer;
import org.mortbay.io.ByteArrayBuffer;
import org.mortbay.jetty.HttpFields;
import org.mortbay.jetty.client.ContentExchange;
import org.mortbay.jetty.client.HttpClient;
import org.mozilla.javascript.Context;
import org.mozilla.javascript.Function;
import org.mozilla.javascript.Scriptable;

/**
 * Implementation of the XMLHttpRequest functionality using Jetty's HttpClient.
 *
 * @version $Revision: 1387 $ $Date: 2009-01-13 17:18:38 -0600 (Tue, 13 Jan 2009) $
 */
public class XMLHttpRequestClient
{
    private final HttpClient httpClient;

    public XMLHttpRequestClient()
    {
        httpClient = new HttpClient();
        httpClient.setMaxConnectionsPerAddress(2);
        httpClient.setSoTimeout(0);
        httpClient.setIdleTimeout(300000);
        httpClient.setTimeout(300000);
        httpClient.setConnectorType(HttpClient.CONNECTOR_SOCKET);
    }

    public XMLHttpRequestClient start() throws Exception
    {
        httpClient.start();
        return this;
    }

    public XMLHttpRequestExchange newExchange(Scriptable thiz, Function function, String method, String url)
    {
        return new XMLHttpRequestExchange(thiz, function, method, url);
    }

    public void send(XMLHttpRequestExchange exchange) throws IOException
    {
        httpClient.send(exchange);
    }

    public static class XMLHttpRequestExchange extends ContentExchange
    {
        public enum ReadyState
        {
            UNSENT, OPENED, HEADERS_RECEIVED, LOADING, DONE
        }

        private final Scriptable thiz;
        private final Function function;
        private boolean aborted;
        private ReadyState readyState = ReadyState.UNSENT;
        private String responseText;
        private String responseStatusText;
        private HttpFields responseFields;

        public XMLHttpRequestExchange(Scriptable thiz, Function function, String method, String url)
        {
            responseFields=new HttpFields();
            this.thiz = thiz;
            this.function = function;
            setMethod(method == null ? "GET" : method.toUpperCase());
            setURL(url);
            aborted = false;
            readyState = ReadyState.OPENED;
            responseStatusText = null;
            getRequestFields().clear();
            notifyReadyStateChange();
        }

        private void notifyReadyStateChange()
        {
            Context context = Context.enter();
            try
            {
                function.call(context, thiz, thiz, new Object[0]);
            }
            finally
            {
                Context.exit();
            }
        }

        @Override
        public synchronized void cancel()
        {
            super.cancel();
            aborted = true;
            responseText = null;
            getRequestFields().clear();
            if (readyState == ReadyState.HEADERS_RECEIVED || readyState == ReadyState.LOADING)
            {
                readyState = ReadyState.DONE;
                notifyReadyStateChange();
            }
            readyState = ReadyState.UNSENT;
        }

        public synchronized int getReadyState()
        {
            return readyState.ordinal();
        }

        public synchronized String getResponseText()
        {
            return responseText;
        }

        @Override
        public synchronized int getResponseStatus()
        {
            return super.getResponseStatus();
        }

        public synchronized String getResponseStatusText()
        {
            return responseStatusText;
        }

        public synchronized void setRequestContent(String content) throws UnsupportedEncodingException
        {
            setRequestContent(new ByteArrayBuffer(content, "UTF-8"));
        }

        public synchronized String getAllResponseHeaders()
        {
            return responseFields.toString();
        }

        public synchronized String getResponseHeader(String name)
        {
            return responseFields.getStringField(name);
        }

        @Override
        protected synchronized void onResponseStatus(Buffer version, int status, Buffer statusText) throws IOException
        {
            super.onResponseStatus(version, status, statusText);
            this.responseStatusText = new String(statusText.asArray(), "UTF-8");
        }

        @Override
        protected void onResponseHeader(Buffer name, Buffer value) throws IOException
        {
            if (responseFields != null)
                responseFields.add(name,value);
            super.onResponseHeader(name,value);
        }
        
        @Override
        protected synchronized void onResponseHeaderComplete() throws IOException
        {
            super.onResponseHeaderComplete();
            if (!aborted)
            {
                readyState = ReadyState.HEADERS_RECEIVED;
                notifyReadyStateChange();
            }
        }

        @Override
        protected synchronized void onResponseContent(Buffer buffer) throws IOException
        {
            super.onResponseContent(buffer);
            if (!aborted)
            {
                if (readyState != ReadyState.LOADING)
                {
                    readyState = ReadyState.LOADING;
                    notifyReadyStateChange();
                }
            }
        }

        @Override
        protected synchronized void onResponseComplete() throws IOException
        {
            super.onResponseComplete();
            if (!aborted)
            {
                responseText = getResponseContent();
                readyState = ReadyState.DONE;
                notifyReadyStateChange();
            }
        }

        @Override
        protected void onConnectionFailed(Throwable x)
        {
            super.onConnectionFailed(x);
            System.out.println("CONNECTION FAILED: " + x);
        }

        @Override
        protected void onException(Throwable x)
        {
            super.onException(x);
            System.out.println("EXCEPTION: " + x);
        }
    }
}
