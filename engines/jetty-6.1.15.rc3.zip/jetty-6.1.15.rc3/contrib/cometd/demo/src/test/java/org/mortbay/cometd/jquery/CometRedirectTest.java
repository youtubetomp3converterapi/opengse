package org.mortbay.cometd.jquery;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.mortbay.jetty.Handler;
import org.mortbay.jetty.servlet.Context;
import org.mortbay.jetty.servlet.FilterHolder;

/**
 * @version $Revision: 1361 $ $Date: 2008-12-16 04:59:27 -0600 (Tue, 16 Dec 2008) $
 */
public class CometRedirectTest extends CometTest
{
    @Override
    protected void customizeContext(Context context)
    {
        Filter filter = new RedirectOnceFilter();
        FilterHolder filterHolder = new FilterHolder(filter);
        context.addFilter(filterHolder, cometServletPath + "/*", Handler.REQUEST);
    }

//    @Test
    public void testCometRedirect() throws Exception
    {
        String script = "$.comet.init('" + cometURL + "')";
        evaluateScript(script);
        Thread.sleep(300000);
    }

    public static class RedirectOnceFilter implements Filter
    {
        private volatile boolean redirect;

        public void init(FilterConfig filterConfig) throws ServletException
        {
        }

        public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException
        {
            doFilter((HttpServletRequest)request, (HttpServletResponse)response, chain);
        }

        private void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException
        {
            StringBuilder url = new StringBuilder(request.getScheme()).append("://").append(request.getServerName());
            url.append(":").append(request.getServerPort()).append(request.getRequestURI());
            System.out.println("Request to: " + url);
            redirect = !redirect;
            if (redirect)
                response.sendRedirect(request.getScheme() + "://comet." + request.getServerName() + ":" + request.getServerPort() + request.getRequestURI());
//                response.sendRedirect("http://google.com");
            else
                chain.doFilter(request, response);
        }

        public void destroy()
        {
        }
    }
}
