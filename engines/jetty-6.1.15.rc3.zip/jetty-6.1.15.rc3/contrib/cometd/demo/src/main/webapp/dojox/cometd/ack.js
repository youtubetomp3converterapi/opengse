/*
 Copyright (c) 2004-2008, The Dojo Foundation All Rights Reserved.
 Available via Academic Free License >= 2.1 OR the modified BSD license.
 see: http://dojotoolkit.org/license for details
 */

if (!dojo._hasResource["dojox.cometd.ack"])
{
    //_hasResource checks added by build. Do not use _hasResource directly in your code.
    dojo._hasResource["dojox.cometd.ack"] = true;
    dojo.provide("dojox.cometd.ack");
    dojo.require("dojox.cometd._base");

    // A cometd extension that adds a last acked id to every outgoing polling message
    dojox.cometd.ack = new function()
    {
        var supportAcks = false;
        var lastAck = -1;

        this._in = function(msg)
        {        	
            // process all incoming messages, ack the last that has been processed
            if (msg.channel == "/meta/handshake")
            {
                supportAcks = msg.ext && msg.ext.ack;
            }
            // TODO: make it smart enough to handle skipped messages
            // TODO: what happens if lastAck > msgid?
            if (supportAcks)
            {
                if (msg.ext && msg.ext.ack)
                {
                    var ackId = parseInt(msg.ext.ack);
                    if (lastAck < ackId) lastAck = ackId;
                }
                else
                {
                    // Server said it supports acks on handshake, but does not send them, ignore.
                }
            }
            return msg;
        }

        this._out = function(msg)
        {
            if (msg.channel == "/meta/handshake")
            {
                if (!msg.ext) msg.ext = {};
                msg.ext.ack = true;
            }
            
        	// do nothing if we don't support acks 
        	if (!supportAcks)
        		return msg;

            if (msg.channel == "/meta/connect")
            {
                if (!msg.ext) msg.ext = {};
                msg.ext.ack = lastAck;
            }
            return msg;
        }

        this.acknowledge = function(ack)
        {
            lastAck = ack;
        }

        this.getLastAck = function()
        {
            return lastAck;
        }
    };

    dojox.cometd._extendInList.push(dojo.hitch(dojox.cometd.ack, "_in"));
    dojox.cometd._extendOutList.push(dojo.hitch(dojox.cometd.ack, "_out"));
}
