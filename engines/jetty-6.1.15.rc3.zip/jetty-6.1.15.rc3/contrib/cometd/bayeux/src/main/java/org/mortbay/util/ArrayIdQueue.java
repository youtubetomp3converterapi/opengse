package org.mortbay.util;

import java.util.Iterator;
import java.util.NoSuchElementException;

import org.mortbay.util.ArrayQueue;

public class ArrayIdQueue<E> extends ArrayQueue<E>
{
    private long[] _ids;
    private long _currentId;
    private int _unacked;
    private int _cursor;

    /* ------------------------------------------------------------ */
    public ArrayIdQueue()
    {
        super();
        _ids=new long[DEFAULT_CAPACITY];
    }

    /* ------------------------------------------------------------ */
    public ArrayIdQueue(int capacity)
    {
        super(capacity);
        _ids=new long[capacity];
    }

    /* ------------------------------------------------------------ */
    public ArrayIdQueue(int initCapacity, int growBy)
    {
        super(initCapacity,growBy);
        _ids=new long[initCapacity];
    }

    /* ------------------------------------------------------------ */
    public ArrayIdQueue(int initCapacity, int growBy, Object lock)
    {
        super(initCapacity,growBy,lock);
        _ids=new long[initCapacity];
    }

    /**
     * @param unacked marks which messages have been sent, and are awaiting a
     * response. The index is the first message that has not yet been sent
     */
    /* ------------------------------------------------------------ */
    public int getUnackedIndex()
    {
        return _unacked;
    }

    /* ------------------------------------------------------------ */
    public void incrementUnackedIndex()
    {
        _unacked++;
    }

    /* ------------------------------------------------------------ */
    public void decrementUnackedIndex()
    {
        _unacked--;
    }

    /* ------------------------------------------------------------ */
    /**
     * @return currentId the latest batch that has been sent to the client
     */
    public long getCurrentId()
    {
        return _currentId;
    }
    
    public void setCurrentId(int currentId)
    {
        _currentId=currentId;
    }

    public void incrementCurrentId()
    {
        _currentId++;
    }

    /* ------------------------------------------------------------ */
    public boolean add(E e)
    {
        synchronized (_lock)
        {
            int nextSlot=_nextSlot;
            super.add(e);
            _ids[nextSlot]=_currentId;
        }
        return true;
    }

    /* ------------------------------------------------------------ */
    public void addUnsafe(E e)
    {
        int nextSlot=_nextSlot;
        super.addUnsafe(e);
        _ids[nextSlot]=_currentId;

    }

    /* ------------------------------------------------------------ */
    public boolean offer(E e)
    {
        int nextSlot = _nextSlot;
        int nextE = _nextE;
        
        _ids[nextSlot]=_currentId;
        
        boolean offer = super.offer(e);
        if(!offer) return false;
        
        long[] ids=new long[_elements.length];

        int split=_ids.length-nextE;
        if (split>0)
            System.arraycopy(_ids,nextE,ids,0,split);
        if (nextE!=0)
            System.arraycopy(_ids,0,ids,split,nextSlot);

        _ids=ids;

        return offer;

    }

    /* ------------------------------------------------------------ */
    public long getAssociatedId(int index)
    {
        synchronized(_lock)
        {
            if (index<0 || index>=_size)
                throw new IndexOutOfBoundsException("!("+0+"<"+index+"<="+_size+")");
            int i = _nextE+index;
            if (i>=_ids.length)
                i-=_ids.length;
            return _ids[i];
        }
    }

    /* ------------------------------------------------------------ */
    public long getAssociatedIdUnsafe(int index)
    {
        int i = _nextE+index;
        if (i>=_ids.length)
            i-=_ids.length;
        return _ids[i];
    }

    /* ------------------------------------------------------------ */
    public E remove(int index)
    {
        synchronized(_lock)
        {
            int nextSlot = _nextSlot;
            E e = super.remove(index);

            int i = _nextE+index;
            if (i>=_ids.length)
                i-=_ids.length;
            
            if (i<nextSlot)
            {
                System.arraycopy(_ids,i+1,_ids,i,nextSlot-i);
                nextSlot--;
            }
            else
            {
                System.arraycopy(_ids,i+1,_ids,i,_ids.length-1);
                if (nextSlot>0)
                {
                    _ids[_ids.length]=_ids[0];
                    System.arraycopy(_ids,1,_ids,0,nextSlot-1);
                    nextSlot--;
                }
                else
                    nextSlot=_ids.length-1;

            }
            
            return e;
        }
    }

    /* ------------------------------------------------------------ */
    public E set(int index, E element)
    {
        synchronized(_lock)
        {
            E old = super.set(index, element);

            int i = _nextE+index;
            if (i>=_ids.length)
                i-=_ids.length;
            // TODO: what if the id is not meant to be the latest? 
            _ids[i]=_currentId;
            return old;
        }
    }
    
    /* ------------------------------------------------------------ */
    public void add(int index, E element)
    {
        synchronized(_lock)
        {
            int nextSlot = _nextSlot;
            super.add(index, element);
            
            if (index==_size)
            {
                _ids[index] = _currentId;
            }
            else
            {
                int i = _nextE+index;
                if (i>=_ids.length)
                    i-=_ids.length;

                if (i<nextSlot)
                {
                    System.arraycopy(_ids,i,_ids,i+1,nextSlot-i);
                    _ids[i]=_currentId;
                }
                else
                {
                    if (nextSlot>0)
                    {
                        System.arraycopy(_ids,0,_ids,1,nextSlot);
                        _ids[0]=_ids[_ids.length-1];
                    }

                    System.arraycopy(_ids,i,_ids,i+1,_ids.length-i-1);
                    _ids[i]=_currentId;
                }
            }
        }
    }

    public E get(int index)
    {
        _cursor = index;
        return super.get(index);
    }
    
    protected void grow()
    {
        int nextE=_nextE;
        int nextSlot=_nextSlot;

        super.grow();

        long[] Ids=new long[_elements.length];
        int split=_ids.length - nextE;
        if (split > 0)
            System.arraycopy(_ids,nextE,Ids,0,split);
        if (nextE != 0)
            System.arraycopy(_ids,0,Ids,split,nextSlot);

        _ids=Ids;
    }
    
    
    /**
     * @return idIterator an iterator over the associated ids
     */
    public ArrayIdIterator idIterator()
    {
        return new ArrayIdIterator(iterator());
    }
    
    public class ArrayIdIterator implements Iterator<E> 
    {
        private Iterator<E> _iterator;
        
        public ArrayIdIterator(Iterator<E> iterator)
        {
            _iterator = iterator;
        }

        /* ------------------------------------------------------------ */
        /**
         * @return the id associated with the current element in the iteration
         */
        public long associatedId()
        {
            try {
                long nextId = ArrayIdQueue.this.getAssociatedId(ArrayIdQueue.this._cursor);
                return nextId;
            } catch(IndexOutOfBoundsException e) {
                throw new NoSuchElementException();
            }            
        }

        /* ------------------------------------------------------------ */
        public long nextId() {
            try {
                next();
                long nextId = ArrayIdQueue.this.getAssociatedId(ArrayIdQueue.this._cursor);
                return nextId;
            } catch(IndexOutOfBoundsException e) {
                throw new NoSuchElementException();
            }
        }
        
        /* ------------------------------------------------------------ */        
        public boolean hasNext()
        {
            return _iterator.hasNext();
        }

        /* ------------------------------------------------------------ */
        public E next()
        {
            return _iterator.next();
        }

        /* ------------------------------------------------------------ */
        public void remove()
        {
            _iterator.remove();
        }
    }

}
